리스크 탐지봇 — 워크플로우 및 데이터 파일

[workflows] GitHub Actions 워크플로우
  news_monitor.yml        메인 파이프라인. 수집→필터→AI 판정→익스포저 매칭→발송 (하루 3회)
  dart_mapper.yml         DART 지분관계 수집. 주 1회 월요일, 그룹 계열사 매핑 갱신
  manual_send.yml         수동 발송(회차 지정 재발송)
  test_full_pipeline.yml  전체 파이프라인 회귀 테스트
  test_send_self.yml      자체 확인용 발송 테스트
  verify_send.yml         발송 결과 검증
  diag_exposure.yml       익스포저 데이터 진단
  diag_keyword_volume.yml 키워드별 수집량 진단

[json] 운영 데이터
  known_cases.json        진행 중 사건 목록. 반복 탐지 억제용, 필터 프롬프트에 동적 주입
  group_map.json          그룹 계열사 매핑 (DART 지분관계 기반 자동 생성)
  dart_corp_codes.json    DART 기업 고유코드 사전
  dart_relation_cache.json DART 조회 결과 캐시 (무결과 캐시 겸 커서, 28일 만료)
  ticker_map.json         종목명 ↔ 티커 매핑
  regression_set.json     회귀 테스트 기사 세트 (오탐·정탐·미탐 케이스)
  run_stats.jsonl         회차별 운영 지표 (수집·선별 건수, AI 모델, 발송 범위)

※ 고객 익스포저 데이터(exposure_data.csv)는 종목 단위 집계값이며 본 압축본에서 제외했습니다.
